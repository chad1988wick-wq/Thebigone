# QuotePilot Vercel demo
This is a STATIC DEMO, not the production SaaS. Data is stored in the browser's localStorage and is not shared across devices. There is no real authentication, billing, sending, or database.

Deploy: push this folder's files to a GitHub repository, then Vercel > Add New > Project > Import repository. Choose Other framework; no build command needed. The `index.html` is the homepage.

For the full SaaS implementation, use `QUOTEPILOT_BUILD_SPEC.md`.
